Please refer to the [Virtual Assistant Template documentation](http://aka.ms/virtualassistantdocs) for deployment and customization instructions.
